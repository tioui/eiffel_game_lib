Create the ressource with the tool custom_package_file (that you can compile from the $GAME_EIF_LIB/custom_package_file/custom_package_file.ecf project)

Command line used:
        custom_package_file create ressources.cpf bubbles.ogv curtain.ogv font.ttf
        ^                 ^ ^    ^ ^            ^ ^         ^ ^         ^ ^       ^
	 \_______________/   \__/   \__________/   \_______/   \_______/   \_____/ 
             Prog name      Option   Output file     file1       file2      file3  
 
Copy the resulting ressources.cpf to the project directory.

Use it as explain in the exemple.
