Objects that are able to iterate over a {CHAIN} structures (forward and backward) 
and the content can be addressed with integers key.
Can be use to access a {CHAIN} in read only (for a {CHAIN} atribute).

MIT License (see http://opensource.org/licenses/MIT)
