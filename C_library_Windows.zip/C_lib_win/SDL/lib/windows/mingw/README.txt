Renamed libSDL.dll.a as SDL.lib
Renamed libSDLmain.a as SDLmain.lib