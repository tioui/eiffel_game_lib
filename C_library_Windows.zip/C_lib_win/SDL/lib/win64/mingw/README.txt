Renamed libSDL.dll.a to SDL.lib
Renamed libSDLmain.a to SDLmain.lib