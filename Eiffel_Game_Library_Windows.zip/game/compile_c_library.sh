#!/bin/sh
cd cpf_lib/Clib
finish_freezing -library
cd ../../game_core_lib/Clib
finish_freezing -library
cd ../../audio_snd_files_lib/Clib
finish_freezing -library
cd ../../audio_video_lib/Clib
finish_freezing -library
