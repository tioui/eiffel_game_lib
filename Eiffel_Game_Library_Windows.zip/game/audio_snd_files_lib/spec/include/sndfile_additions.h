#ifndef AUDIO_MORE_H
#define AUDIO_MORE_H
#include <sndfile.h>
#include "cpf_additions.h"

void setSndFileVirtualIo(SF_VIRTUAL_IO *VirtualIO);

#endif
